-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2024 at 10:14 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `dt_headings`
--

CREATE TABLE `dt_headings` (
  `id` int(11) NOT NULL,
  `home_heading` varchar(255) NOT NULL,
  `home_description` text NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dt_process`
--

CREATE TABLE `dt_process` (
  `id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `heading` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_alt` varchar(255) NOT NULL,
  `webp` varchar(255) NOT NULL,
  `short_description` text NOT NULL,
  `add_date` datetime NOT NULL,
  `update_date` datetime NOT NULL,
  `status` enum('Active','Inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dt_process`
--

INSERT INTO `dt_process` (`id`, `priority`, `heading`, `image`, `image_alt`, `webp`, `short_description`, `add_date`, `update_date`, `status`) VALUES
(1, 1, 'Testing...', '1728459263_82c29d281439fc72066e.png', 'Test-image', '1728459263_82c29d281439fc72066e.webp', 'Testing...Short Description', '2024-10-09 07:34:23', '0000-00-00 00:00:00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `dt_setting`
--

CREATE TABLE `dt_setting` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `whatsapp` varchar(200) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `mobile2` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL,
  `email_id` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `copyright` varchar(255) NOT NULL,
  `map_script` text NOT NULL,
  `facebook_link` varchar(255) NOT NULL,
  `youtube_link` varchar(255) NOT NULL,
  `instagram_link` varchar(255) NOT NULL,
  `linkedin_link` varchar(255) NOT NULL,
  `add_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `logo` varchar(255) NOT NULL,
  `logo_webp` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_webp` varchar(255) NOT NULL,
  `logo_alt` varchar(255) NOT NULL,
  `location_image` varchar(255) NOT NULL,
  `location_image_webp` varchar(255) NOT NULL,
  `faq_image` varchar(255) NOT NULL,
  `faq_image_webp` varchar(255) NOT NULL,
  `about_image1` varchar(200) NOT NULL,
  `about_image1_webp` varchar(200) NOT NULL,
  `about_image2` varchar(200) NOT NULL,
  `about_image2_webp` varchar(200) NOT NULL,
  `email2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dt_setting`
--

INSERT INTO `dt_setting` (`id`, `company_name`, `whatsapp`, `mobile`, `mobile2`, `favicon`, `email_id`, `address`, `copyright`, `map_script`, `facebook_link`, `youtube_link`, `instagram_link`, `linkedin_link`, `add_date`, `update_date`, `logo`, `logo_webp`, `image`, `image_webp`, `logo_alt`, `location_image`, `location_image_webp`, `faq_image`, `faq_image_webp`, `about_image1`, `about_image1_webp`, `about_image2`, `about_image2_webp`, `email2`) VALUES
(1, 'Suraj-Demo', '9876543210', '1234567890', '9876543210', '1728455976_bc009ef217565b9dd7c7.png', 'suraj@gmail.com', 'Lucknow-Uttar Pradesh', 'Suraj Kushwaha | All Rights Reserved.', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.1961950285468!2d80.95239937450431!3d26.897267860755893!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399957c56e81ab71%3A0x44ba6db311859e61!2sGulacheen%20Temple%2C%20Lucknow!5e0!3m2!1sen!2sin!4v1728456190089!5m2!1sen!2sin', 'https://www.facebook.com/suraj/', 'https://www.youtube.com/suraj/', 'https://www.instagram.com/suraj/', 'https://www.linkedin.com/suraj', NULL, NULL, '1727688709_b6843c41d3c4c8fc7cb6.jpg', '1727688709_b6843c41d3c4c8fc7cb6.webp', '', '', 'Logo-Suraj', '1726742857_ae19b7be026e40d3ef7c.png', '1726742857_ae19b7be026e40d3ef7c.webp', '1722948000_ff0f6102e1ce41e89605.jpg', '1722948000_ff0f6102e1ce41e89605.webp', '1726643458_d630e4a6e17aa0d2c906.png', '1726643458_d630e4a6e17aa0d2c906.webp', '1723277602_fe0087440aeac6efcccf.jpg', '1723277602_fe0087440aeac6efcccf.webp', 'info@ithinkdigital.in');

-- --------------------------------------------------------

--
-- Table structure for table `dt_user`
--

CREATE TABLE `dt_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `image` varchar(250) NOT NULL,
  `video` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `add_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dt_user`
--

INSERT INTO `dt_user` (`id`, `name`, `phone`, `image`, `video`, `email`, `password`, `address`, `add_date`, `update_date`) VALUES
(1, 'Suraj-Demo', '1234567890', '1728455949_4b622a43f0ed5e4470a3.png', '', 'suraj@gmail.com', 'suraj@123', 'Lucknow', NULL, '2024-10-09 06:39:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dt_headings`
--
ALTER TABLE `dt_headings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dt_process`
--
ALTER TABLE `dt_process`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dt_setting`
--
ALTER TABLE `dt_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dt_user`
--
ALTER TABLE `dt_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dt_headings`
--
ALTER TABLE `dt_headings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dt_process`
--
ALTER TABLE `dt_process`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dt_setting`
--
ALTER TABLE `dt_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dt_user`
--
ALTER TABLE `dt_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
