<?php
namespace App\Controllers;
use App\Models\Common_model;
class Common extends BaseController
{
    public $model;
    public $session;

    public function __construct()
    {
        $this->model = new Common_model();
        $this->session = session();
    }

    public function index()
    {
        $uri = service('uri');
        $url = $uri->setSilent()->getSegment(1);
        
        if ($url == "about") {
            $this->LoadAbout();
        } else{
            $this->LoadErrorPage();
        }
    }

    public function LoadErrorPage()
    {
        $data = [];
        $data['about'] = $this->model->getSingleData("cms", "*",['url' => 'about-us']);
        webView('404', $data);
    }


    public function LoadAbout()
    {
        $data = [];
        $data['about'] = $this->model->getSingleData("cms", "*",['url' => 'about-us']);
        // print_r($data['cms']); die('test');

        webView('about', $data);
    }

}


