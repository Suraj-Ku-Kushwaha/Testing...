<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Common_model;

class Profile extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new Common_model();
    }

    public function index()
    {
        $data = [];
       
        return admin_view("profile", $data);
    } 
}
?>