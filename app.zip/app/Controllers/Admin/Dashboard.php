<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Common_model;
class Dashboard extends BaseController
{
    public function __construct(){
        $this->model = new Common_model();
    }
    
    public function index()
    {
        $data = [];
         admin_view('index',$data);
    }
    
  public function getCount() {
        $type = $this->request->getVar('type') ??"";
        $table = $this->request->getVar('table') ??"";
    
        // if (in_array($table, ['dt_gallery','dt_news', 'dt_cms'])) {
           
        // }

        $count = count_data('id', $table);
        echo $count;
    }
}
