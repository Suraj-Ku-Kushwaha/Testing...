<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Common_model;

class Login extends BaseController
{
    protected $model;
    public function __construct()
    {
        $this->model = new Common_model();
        $this->session = session();
    }

    public function login()
    {
        $data = [];
          $data['settings'] =  $this->model->getSingleData("setting", "*",['id' => '1']);
          $data['headings'] = $this->model->getSingleData("headings", "*",['id' => '1']);
        return view("admin/login", $data);
    }
    public function checkLogin()
    {
        $data = [];
        $session =  $this->session;
        $post = $this->request->getVar();
    $email = $post['email'];
    $password = $post["password"];
    $table = "dt_user";
    $select = "*";
    $where = ['email'=>$email,'password'=>$password];
    $data = $this->model->checkLogin($table,$select,$where);
    if(!empty($data)){
        $sessionArray = [
            'id' => $data['id'],
            'name' => $data['name'],
            'email' => $data['email'],
            'image' => $data['image'],
            'isLoggedIn' => TRUE
        ];
    $session->set(['LoginData'=> $sessionArray]);
    $session->setFlashdata('success','login Successful');
    return redirect()->to(base_url('admin'));
    }  else{
        $this->session->setFlashdata('error','invalid login');
        return redirect()->to(base_url('admin/login'));
    }
   }
   public function logout(){
    $session =  $this->session;
    $session->set(['LoginData'=> []]);
    return redirect()->to(base_url('admin/login'));
   }

}
?>
