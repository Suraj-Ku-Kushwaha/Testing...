<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Common_model;

class Process extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new Common_model();
        $this->session = session();
    }

    public function add()
    {
        $data = [];
        $id = !empty($this->request->getVar("id")) ? $this->request->getVar("id") : "";
        $processData = $this->model->getSingleData("process", "*",['id' => $id]);
        $data['id'] = !empty($processData['id'] ) ? $processData['id'] : "";
        $data['image'] = !empty($processData['image'] ) ? $processData['image'] : "";
        $data['status'] = !empty($processData['status'] ) ? $processData['status'] : "";
        $data['webp'] = !empty($processData['webp'] ) ? $processData['webp'] : "";
         $data['priority'] = !empty($processData['priority'] ) ? $processData['priority'] : "";
        $data['image_alt'] = !empty($processData['image_alt'] ) ? $processData['image_alt'] : "";
        $data['heading'] = !empty($processData['heading'] ) ? $processData['heading'] : "";
        $data['short_description'] = !empty($processData['short_description'] ) ? $processData['short_description'] : "";
        return admin_view("add-process", $data);
    } 

    public function save()
    {
        $data = [];
        $post = $this->request->getVar();
        $id = !empty($this->request->getVar("id")) ? $this->request->getVar("id") : "";
        $data["image_alt"] = trim(!empty($post["image_alt"]) ? $post["image_alt"] : "");
        $data["heading"] = trim(!empty($post["heading"]) ? $post["heading"] : "");
          $data["priority"] = trim(!empty($post["priority"]) ? $post["priority"] : "");
        $data["short_description"] = trim(!empty($post["short_description"]) ? $post["short_description"] : "");
        $oldimage = trim(!empty($post['oldimage']) ? $post['oldimage'] : "");
        $oldwebp = trim(!empty($post['oldwebp']) ? $post['oldwebp'] : "");
        $data['status'] = trim(!empty($post['status']) ? $post['status'] : "Inactive");


  
        if($image = $this->request->getFile('image'))
        {
            if ($image->isValid() && ! $image->hasMoved())
            {
                 if(!empty($oldimage)){
                    unlink_image(ROOTPATH . "uploads/" . $oldimage);
                }
                if(!empty($oldwebp)){
                    unlink_image(ROOTPATH . "uploads/" . $oldwebp);
                }
                
                
                $newName = $image->getRandomName();
                $image->move(ROOTPATH . 'uploads/', $newName);
                $data['image'] = $newName;
                $webpfileName = pathinfo($newName, PATHINFO_FILENAME).'.webp';
                $webp_image = convertImageInToWebp(ROOTPATH . 'uploads/',$newName,$webpfileName);
                $data['webp'] = $webp_image;
            }
        }
        

        if (!empty($id)) {
            $data['update_date'] =  date('Y-m-d H:i:s');
            $this->session->setFlashdata('success','Data Updated');

            $processData = $this->model->updateData("process",["id" => $id], $data);
        } else {
            $data['add_date'] =  date('Y-m-d H:i:s');
              $this->session->setFlashdata('success','Data Added');
            $processData = $this->model->insertData("process", $data);
        }


        return redirect()->to(base_url("admin/process-list"));
    }



    
    public function display()
    {
        $data = [];
        $processData = $this->model->getAllData("process", "*",null,'id desc');
        $data["processData"] = $processData;
        return admin_view("process-list", $data);
    }

    public function delete()
    {
        $id = !empty($this->request->getVar("id")) ? $this->request->getVar("id") : "";
        $data = $this->model->getSingleData("process","*",['id'=>$id]);
        
        if(!empty($data)){
            $image = $data['image'] ?? '';
            $video = $data['video'] ?? '';
            $webp = $data['webp'] ?? '';
            
            if(!empty($image)){
                 unlink_image(ROOTPATH . "uploads/" . $image);
            }
            
            if(!empty($webp)){
                  unlink_image(ROOTPATH . "uploads/" . $webp);
            }
            
            if(!empty($video)){
                 unlink_image(ROOTPATH . "uploads/" . $video);
            }
        }
        
       
        
        
        $this->model->deleteData("process", ["id" => $id]);
        $this->session->setFlashdata('success','Data Deleted');
        return redirect()->to(base_url("admin/process-list"));
    }
}