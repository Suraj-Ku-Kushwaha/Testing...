<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Common_model;

class Settings extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new Common_model();
        $this->session = session();
        $this->validation = \Config\Services::validation();
    }


    public function index()
    {
        $data = [];
        $settingData = $this->model->getSingleData("dt_setting", "*");
        $data["id"] = !empty($settingData["id"]) ? $settingData["id"] : "";	
        $data["company_name"] = !empty($settingData["company_name"]) ? $settingData["company_name"] : "";
        $data["mobile"] = !empty($settingData["mobile"]) ? $settingData["mobile"] : "";
        $data["mobile2"] = !empty($settingData["mobile2"]) ? $settingData["mobile2"] : "";
        $data["favicon"] = !empty($settingData["favicon"]) ? $settingData["favicon"] : "";
        $data["email_id"] = !empty($settingData["email_id"]) ? $settingData["email_id"] : "";
        $data["address"] = !empty($settingData["address"]) ? $settingData["address"] : "";
        $data["map_script"] = !empty($settingData["map_script"]) ? $settingData["map_script"] : "";
        $data["title"] = !empty($settingData["Update Setting"]) ? $settingData["Add Setting"] : "";
        $data["facebook_link"] = !empty($settingData["facebook_link"]) ? $settingData["facebook_link"] : "";
        $data["youtube_link"] = !empty($settingData["youtube_link"]) ? $settingData["youtube_link"] : "";
        $data["linkedin_link"] = !empty($settingData["linkedin_link"]) ? $settingData["linkedin_link"] : "";
        $data["instagram_link"] = !empty($settingData["instagram_link"]) ? $settingData["instagram_link"] : "";
        $data["logo"] = !empty($settingData["logo"]) ? $settingData["logo"] : "";
        $data["logo_webp"] = !empty($settingData["logo_webp"]) ? $settingData["logo_webp"] : "";
        $data["logo_alt"] = !empty($settingData["logo_alt"]) ? $settingData["logo_alt"] : "";
        $data["location_image"] = !empty($settingData["location_image"]) ? $settingData["location_image"] : "";
        $data["location_image_webp"] = !empty($settingData["location_image_webp"]) ? $settingData["location_image_webp"] : "";
        $data["webp"] = !empty($settingData["webp"]) ? $settingData["webp"] : "";
        $data["whatsapp"] = !empty($settingData["whatsapp"]) ? $settingData["whatsapp"] : "";
        $data["copyright"] = !empty($settingData["copyright"]) ? $settingData["copyright"] : "";
        $data["faq_image"] = !empty($settingData["faq_image"]) ? $settingData["faq_image"] : "";
        $data["faq_image_webp"] = !empty($settingData["faq_image_webp"]) ? $settingData["faq_image_webp"] : "";
        $data["about_image1"] = !empty($settingData["about_image1"]) ? $settingData["about_image1"] : "";
        $data["about_image1_webp"] = !empty($settingData["about_image1_webp"]) ? $settingData["about_image1_webp"] : "";
        $data["about_image2"] = !empty($settingData["about_image2"]) ? $settingData["about_image2"] : "";
        $data["about_image2_webp"] = !empty($settingData["about_image2_webp"]) ? $settingData["about_image2_webp"] : "";
        $data["email2"] = !empty($settingData["email2"]) ? $settingData["email2"] : "";
        return admin_view("settings", $data);
    }

    public function saveSettings()
    {
        $data = [];
        $post = $this->request->getVar();
        $id = !empty($this->request->getVar("id")) ? $this->request->getVar("id") : "";
        $data["company_name"] = isset($post["company_name"]) ? $post["company_name"] : "";
        $data["mobile"] = isset($post["mobile"]) ? $post["mobile"] : "";
        $data["mobile2"] = isset($post["mobile2"]) ? $post["mobile2"] : "";
        $data["address"] = isset($post["address"]) ? $post["address"] : "";
        $data["map_script"] = isset($post["map_script"]) ? $post["map_script"] : "";
        $data["facebook_link"] = isset($post["facebook_link"]) ? $post["facebook_link"] : "";
        $data["youtube_link"] = isset($post["youtube_link"]) ? $post["youtube_link"] : "";
        $data["instagram_link"] = isset($post["instagram_link"]) ? $post["instagram_link"] : "";
        $data["linkedin_link"] = !empty($post["linkedin_link"]) ? $post["linkedin_link"] : "";
        $data["logo_alt"] = isset($post["logo_alt"]) ? $post["logo_alt"] : "";
        $data["whatsapp"] = isset($post["whatsapp"]) ? $post["whatsapp"] : "";
        $data["email_id"] = isset($post["email_id"]) ? $post["email_id"] : "";
        $data["copyright"] = isset($post["copyright"]) ? $post["copyright"] : "";
        $data["email2"] = !empty($post["email2"]) ? $post["email2"] : "";
        
        // echo "<pre>";
        // print_r($data); die('Test');
        
        if($logo = $this->request->getFile('logo'))
        {
            if ($logo->isValid() && ! $logo->hasMoved())
            {
                unlink_image(ROOTPATH . "uploads/" . $post['old_logo']);
                unlink_image(ROOTPATH . "uploads/" . $post['logo_webp']);
                $newName = $logo->getRandomName();
                $logo->move(ROOTPATH . 'uploads/', $newName);
                $data['logo'] = $newName;
                $webpfileName = pathinfo($newName, PATHINFO_FILENAME).'.webp';
                $logo_webp = convertImageInToWebp(ROOTPATH . 'uploads/',$newName,$webpfileName);
                $data['logo_webp'] = $logo_webp;
            }
        }

        // echo "<pre>";
        // print_r($data); die('Test');
        
        if($location_image = $this->request->getFile('location_image'))
        {
            if ($location_image->isValid() && ! $location_image->hasMoved())
            {
                unlink_image(ROOTPATH . "uploads/" . $post['old_location_image']);
                unlink_image(ROOTPATH . "uploads/" . $post['old_location_image_webp']);
                $newName = $location_image->getRandomName();
                $location_image->move(ROOTPATH . 'uploads/', $newName);
                $data['location_image'] = $newName;
                $webpfileName = pathinfo($newName, PATHINFO_FILENAME).'.webp';
                $location_image_webp = convertImageInToWebp(ROOTPATH . 'uploads/',$newName,$webpfileName);
                $data['location_image_webp'] = $location_image_webp;
            }
        }
        
        
   


        if($faq_image = $this->request->getFile('faq_image'))
        {
            if ($faq_image->isValid() && ! $faq_image->hasMoved())
            {
                unlink_image(ROOTPATH . "uploads/" . $post['old_faq_image']);
                unlink_image(ROOTPATH . "uploads/" . $post['old_faq_image_webp']);
                $newName = $faq_image->getRandomName();
                $faq_image->move(ROOTPATH . 'uploads/', $newName);
                $data['faq_image'] = $newName;
                $webpfileName = pathinfo($newName, PATHINFO_FILENAME).'.webp';
                $faq_image_webp = convertImageInToWebp(ROOTPATH . 'uploads/',$newName,$webpfileName);
                $data['faq_image_webp'] = $faq_image_webp;
            }
        }
     

        
        

        if($about_image1 = $this->request->getFile('about_image1'))
        {
            if ($about_image1->isValid() && ! $about_image1->hasMoved())
            {
                unlink_image(ROOTPATH . "uploads/" . $post['old_about_image1']);
                unlink_image(ROOTPATH . "uploads/" . $post['old_about_image1_webp']);
                $newName = $about_image1->getRandomName();
                $about_image1->move(ROOTPATH . 'uploads/', $newName);
                $data['about_image1'] = $newName;
                $webpfileName = pathinfo($newName, PATHINFO_FILENAME).'.webp';
                $about_image1_webp = convertImageInToWebp(ROOTPATH . 'uploads/',$newName,$webpfileName);
                $data['about_image1_webp'] = $about_image1_webp;
            }
        }


       
       




       
        if($favicon = $this->request->getFile('favicon'))
        {
            if ($favicon->isValid() && ! $favicon->hasMoved())
            {
                $newName = $favicon->getRandomName();
                $favicon->move(ROOTPATH . 'uploads/', $newName);
                $data['favicon'] = $newName;
            }
        }


        // echo "<pre>";
        // print_r($data); die('Test');

        if (!empty($id)) {
            $this->session->setFlashdata('success','Data Updated');
            $settingData = $this->model->updateData("dt_setting",["id" => $id],$data);
        } else {
            $this->session->setFlashdata('success','Data Added');
            $settingData = $this->model->insertData("dt_setting", $data);
        }
        return redirect()->to(base_url("admin/settings"));
   }

}
?>