<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\Common_model;

class User extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new Common_model();
    }

    public function addUser()
    {
        $data = [];
        $userData = $this->model->getSingleData("dt_user", "*");
        $data["id"] = !empty($userData["id"]) ? $userData["id"] : "";
        $data["name"] = !empty($userData["name"]) ? $userData["name"] : "";
        $data["image"] = !empty($userData["image"]) ? $userData["image"] : "";
        $data["password"] = !empty($userData["password"]) ? $userData["password"] : "";
        $data["email"] = !empty($userData["email"]) ? $userData["email"] : "";
        $data["address"] = !empty($userData["address"]) ? $userData["address"] : "";
        $data["phone"] = !empty($userData["phone"]) ? $userData["phone"] : "";
        return admin_view("add-user", $data);
    }

    public function saveUser()
    {
        $data = [];
        $post = $this->request->getVar();
        $id = !empty($this->request->getVar("id")) ? $this->request->getVar("id") : "";
        $data["name"] = $post["name"];
         $data["phone"] = $post["phone"];


      if ($image = $this->request->getFile("image")) {
        if ($image->isValid() && !$image->hasMoved()) 
        {
            if (file_exists(ROOTPATH . "uploads/" . $post['old_image'])) {
                @unlink(ROOTPATH . "uploads/" . $post['old_image']);
            }

            $newName = $image->getRandomName();
            $image->move(ROOTPATH . "uploads/", $newName);
            $data["image"] = $newName;
        }   
    }
        
    
        $data["password"] = $post["password"];
        $data["email"] = $post["email"];
        $data["address"] = $post["address"];
        
        if (!empty($id)) {
            $data['update_date'] = date('Y:m:d H:i:s');
            $userData = $this->model->updateData(
                "dt_user",
                ["id" => $id],
                $data
            );
        } else {
            $data['add_date'] = date('Y:m:d H:i:s');

            $userData = $this->model->insertData("dt_user", $data);
        }
        return redirect()->to(base_url("admin/add-user"));
    }
    

}
