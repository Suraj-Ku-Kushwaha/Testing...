<?php
namespace App\Controllers;
use App\Models\Common_model;
class Home extends BaseController
{
    public function __construct()
    {
        $this->model = new Common_model();
        $this->session = session();
    }
    public function index()
    { 
        $data = [];
        $data['process'] = $this->model->getAllData("process", "*",['status' => 'Active'],'priority ASC');
        
        return webView('index',$data);
    }
}
