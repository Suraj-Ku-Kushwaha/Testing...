<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

 $routes->match(['get', 'post'], 'admin/login', 'Login::login',['namespace' => 'App\Controllers\Admin']);
 $routes->match(['get', 'post'], 'admin/check-login', 'Login::checkLogin',['namespace' => 'App\Controllers\Admin']);
 $routes->group('admin',  ['filter' => 'Auth' , 'namespace' => 'App\Controllers\Admin'], static function ($routes) {
 $routes->match(['get', 'post'], 'getCount', 'Dashboard::getCount');
 $routes->match(['get', 'post'], 'logout', 'Login::logout');
 $routes->match(['get', 'post'], '/', 'Dashboard::index');
 
 $routes->match(['get', 'post'], 'add-process', 'Process::add');
 $routes->match(['get', 'post'], 'save-process', 'Process::save');
 $routes->match(['get', 'post'], 'process-list', 'Process::display');
 $routes->match(['get', 'post'], 'delete-process', 'Process::delete');

 $routes->match(['get', 'post'], 'settings', 'Settings::index');
 $routes->match(['get', 'post'], 'save-settings', 'Settings::saveSettings');
 
 $routes->match(['get', 'post'], 'add-user', 'User::addUser');
 $routes->match(['get', 'post'], 'save-user', 'User::saveUser');
 
 $routes->match(['get', 'post'], 'contact-list', 'View_contact::index');
 $routes->match(['get', 'post'], 'delete-contact', 'View_contact::delete');

 });

$routes->group('',  ['namespace' => 'App\Controllers'], static function ($routes) {
    $routes->get('/', 'Home::index');
    $routes->post('save-contact', 'Forms::saveConatact');
    $routes->get('(:any)', 'Common::index');
    
});
    

   