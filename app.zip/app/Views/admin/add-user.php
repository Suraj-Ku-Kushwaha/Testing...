<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <!-- <h1 class="m-0">Forms</h1> -->
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('admin');?>">Home</a></li>
                        <li class="breadcrumb-item active">Register</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="card">
                        <div class="card-header border-0 text-light bg-dark" >
                            <div class="d-flex justify-content-between">
                                <h3 class="card-title">Admin Registration Form</h3>
                            </div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo base_url('admin/save-user'); ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />
                        
                                <input type="hidden" name="id" id="id" value="<?php echo $id;?>">
                                <div class="row">
                                <div class="form-group col-sm-6">
                                    <label for="name"> Name </label>
                                    <input type="text" required value="<?php echo $name;?>" name="name" id="name"
                                      maxlength="40"
                                        class="form-control" placeholder="Enter Name">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="image">Upload Image</label>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <input type="file" name="image" accept="all" class="form-control" id="image"
                                                <?php if(empty($id)){ ?> required <?php } ?>>
                                        </div>
                                        <?php if(!empty($image)) { ?>
                                        <img src="<?php echo base_url('uploads/').$image;?>" height="50" width="50"
                                            alt="">
                                        <?php  }?>
                                        <input type="hidden" name="old_image" value="<?= $image;?>">
                                    </div>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label for="email">Email address</label>
                                    <input type="email" required name="email" value="<?php echo $email;?>"
                                    pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$"
                                        class="form-control" id="email" placeholder="Enter email">
                                </div>
                                <div class="form-group col-sm-4 d-none">
                                    <label for="password">Password</label>
                                    <input type="password" required name="password" value="<?= $password;?>"
                                    onkeydown="return /[a-zA-Z0-9]/i.test(event.key)" minlegth="5" class="form-control" id="password" placeholder="Password">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label for="password">Password</label>
                                    <div class="input-group">
                                        <input type="password" required name="password" value="<?= $password;?>" minlength="5" class="form-control" id="myInputPassword" placeholder="Password">
                                        <span class="input-group-text" id="toggle-password" style="cursor: pointer;" onclick="togglePassword()">
                                        <input type="checkbox" onclick="myFunction()">
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="form-group col-sm-4">
                                    <label for="phone">Phone No.</label>
                                    <input type="text" required name="phone" value="<?= $phone;?>"
                                    minlength="10" onkeypress="return (event.charCode >= 48 &amp;&amp; event.charCode <= 57)" maxlength="10"  class="form-control" id="password" placeholder="Password">
                                </div>
                                
                                <div class="form-group col-sm-12">
                                    <label for="address"> Address </label>
                                    <textarea name="address"  required id="address" cols="4" rows="4"
                                        class="form-control" placeholder="Enter Your Address"><?=$address;?></textarea>
                                </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<aside class="control-sidebar control-sidebar-dark">
</aside>

