<div class="content-wrapper">
   <div class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6">
               <h1 class="m-0"></h1>
            </div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="<?php echo base_url('admin');?>">Home</a></li>
                  <li class="breadcrumb-item active">Settings</li>
               </ol>
            </div>
         </div>
      </div>
   </div>
   <!-- Main content -->
   <div class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-header">
                     <h3 class="card-title">Web Setting</h3>
                  </div>
                  <div class="card-body">
                     <form action="<?php echo base_url('admin/save-settings'); ?>" method="post" enctype="multipart/form-data">
                        <div class="row">
                           <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />
                           <input type="hidden" name="old_location_image"  value="<?=$location_image;?>"  >
                           <input type="hidden" name="old_location_image_webp"  value="<?=$location_image_webp;?>"  >
                           <input type="hidden" name="id"  value="<?=$id;?>"  >
                           <div class="form-group col-sm-12">
                              <label for="company Name"> Company Name </label>
                              <input type="text" required name="company_name"  id="company_name" 
                                 class="form-control" value="<?= $company_name?>" placeholder="Company Name">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="mobile"> Mobile No </label>
                              <input type="text" required name="mobile"  id="mobile" onkeypress="return (event.charCode >= 48 && event.charCode <= 57) || (event.charCode >= 33 && event.charCode <= 47) || (event.charCode >= 58 && event.charCode <= 64) || (event.charCode >= 91 && event.charCode <= 96) || (event.charCode >= 123 && event.charCode <= 126)"
                                 class="form-control" value="<?= $mobile?>" placeholder="Mobile - 91+ ">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="mobile2"> Mobile No -2 </label>
                              <input type="text" required name="mobile2"  id="mobile2" onkeypress="return (event.charCode >= 48 && event.charCode <= 57) || (event.charCode >= 33 && event.charCode <= 47) || (event.charCode >= 58 && event.charCode <= 64) || (event.charCode >= 91 && event.charCode <= 96) || (event.charCode >= 123 && event.charCode <= 126)"
                                 class="form-control" value="<?= $mobile2?>" placeholder="Mobile - 91+ ">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="whatsapp"> Whatsapp No </label>
                              <input type="text" required name="whatsapp"  id="whatsapp" onkeypress="return (event.charCode >= 48 && event.charCode <= 57) || (event.charCode >= 33 && event.charCode <= 47) || (event.charCode >= 58 && event.charCode <= 64) || (event.charCode >= 91 && event.charCode <= 96) || (event.charCode >= 123 && event.charCode <= 126)"
                                 class="form-control" value="<?= $whatsapp?>" placeholder="Mobile - 91+ ">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="email_id">Email </label>
                              <input type="text" required name="email_id"
                                 class="form-control" value="<?=$email_id;?>" id="email_id" placeholder="">
                           </div>
                           <div class="form-group col-sm-3 d-none">
                              <label for="email2">Email 2 </label>
                              <input type="text" required name="email2"
                                 class="form-control" value="<?=$email2;?>" id="email2" placeholder="">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="facebook_link"> Facebook Link </label>
                              <input type="text" name="facebook_link" id="facebook_link" class="form-control" value="<?=$facebook_link;?>">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="youtube_link"> Youtube Link </label>
                              <input type="text" name="youtube_link" id="youtube_link" class="form-control" value="<?=$youtube_link;?>">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="instagram_link"> Instagram Link </label>
                              <input type="text" name="instagram_link" id="instagram_link" class="form-control" value="<?=$instagram_link;?>">
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="linkedin_link"> Linkedin Link </label>
                              <input type="text" name="linkedin_link" id="linkedin_link" class="form-control" value="<?=$linkedin_link;?>">
                           </div>
                           <div class="form-group col-sm-6">
                              <label for="logo">logo</label>
                              <div class="input-group">
                                 <div class="custom-file">
                                    <input type="file" accept="all" name="logo" <?php if(empty($logo)){ ?> required  <?php } ?>
                                       class="form-control" id="logo">
                                    <?php if(!empty($logo)) { ?> 
                                    <img src="<?php echo base_url('uploads/').$logo;?>" class="mx-3 my-3 ' height="70"  width="70" alt="">
                                    <?php } ?>
                                    <input type="hidden" name="old_logo" value="<?=$logo?>" >
                                    <input type="hidden" name="logo_webp"  value="<?=$logo_webp?>">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group col-sm-6">
                              <label for="favicon">Favicon</label>
                              <div class="input-group">
                                 <div class="custom-file">
                                    <input type="file" accept="all" name="favicon" <?php if(empty($favicon)){ ?> required  <?php } ?>
                                       class="form-control" id="logo">
                                    <?php if(!empty($logo)) { ?> 
                                    <img src="<?php echo base_url('uploads/').$favicon;?>" class="mx-3 my-3 ' height="70"  width="70" alt="">
                                    <?php } ?>
                                 </div>
                              </div>
                           </div>
                           <div class="form-group col-sm-6">
                              <label for="location_image">Home Image</label>
                              <div class="input-group">
                                 <div class="custom-file">
                                    <input type="file" accept="all" name="location_image" <?php if(empty($location_image)){ ?> required  <?php } ?>
                                       class="form-control" id="location_image">
                                    <?php if(!empty($location_image)) { ?> 
                                    <img src="<?php echo base_url('uploads/').$location_image;?>" class="mx-3 my-3 ' height="70"  width="70" alt="">
                                    <?php } ?>
                                    <input type="hidden" name="old_location_image" value="<?=$location_image?>" >
                                 </div>
                              </div>
                           </div>
                           <div class="form-group col-sm-6 d-none">
                              <label for="faq_image">Faq Image</label>
                              <div class="input-group">
                                 <div class="custom-file">
                                    <input type="file" accept="all" name="faq_image" <?php if(empty($faq_image)){ ?> required  <?php } ?>
                                       class="form-control" id="faq_image">
                                    <?php if(!empty($faq_image)) { ?> 
                                    <img src="<?php echo base_url('uploads/').$faq_image;?>" class="mx-3 my-3 ' height="70"  width="70" alt="">
                                    <?php } ?>
                                    <input type="hidden" name="old_faq_image" value="<?=$faq_image?>" >
                                    <input type="hidden" name="old_faq_image_webp"  value="<?=$faq_image_webp?>">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group col-sm-6">
                              <label for="about_image1">About Image-1</label>
                              <div class="input-group">
                                 <div class="custom-file">
                                    <input type="file" accept="all" name="about_image1" <?php if(empty($about_image1)){ ?> required  <?php } ?>
                                       class="form-control" id="about_image1">
                                    <?php if(!empty($faq_image)) { ?> 
                                    <img src="<?php echo base_url('uploads/').$about_image1;?>" class="mx-3 my-3 ' height="70"  width="70" alt="">
                                    <?php } ?>
                                    <input type="hidden" name="old_about_image1" value="<?=$about_image1?>" >
                                    <input type="hidden" name="old_about_image1_webp"  value="<?=$about_image1_webp?>">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group col-sm-3">
                              <label for="logo_alt">logo Alt </label>
                              <input type="text" required  value="<?=$logo_alt;?>"  
                                 name="logo_alt" class="form-control" id="logo_alt" 
                                 placeholder="Enter logo Alt">
                           </div>
                           <div class="col-sm-9">
                              <div class="form-group ">
                                 <label for="copyright"> Copyright </label>
                                 <input name="copyright" required id="copyright" value="<?=$copyright;?>"
                                    class="form-control" placeholder="Enter Copyrights">
                              </div>
                           </div>
                           <div class="col-sm-12">
                              <div class="form-group ">
                                 <label for="address"> Address </label>
                                 <input name="address" required id="address" value="<?=$address;?>"
                                    class="form-control" placeholder="Enter Address">
                              </div>
                              <div class="form-group">
                                 <label for="map_script"> Map Srcipt </label>
                                 <textarea name="map_script" required id="map_script" cols="4" rows="4"
                                    class="form-control" placeholder="Enter Your Script"><?= $map_script;?></textarea>
                              </div>
                           </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<aside class="control-sidebar control-sidebar-dark"></aside>