<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <!-- <h1 class="m-0">Forms</h1> -->
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('admin');?>">Home</a></li>
                        <li class="breadcrumb-item active">Add Testing</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                <h3 class="card-title">Add Testing</h3>
                                <h3 class="card-title d-flex"><a href="<?php echo base_url('admin/process-list');?>"
                                        class="btn btn-primary">Testing list</a></h3>
                            </div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo base_url('admin/save-process'); ?>" method="post"
                                enctype="multipart/form-data">
                                <div class="row">
                                    <input type="hidden" name="id" id="id" value="<?= $id;?>">
                                    <input type="hidden" name="oldimage"  value="<?= $image;?>">
                                    <input type="hidden" name="oldwebp"  value="<?= $webp;?>">
                                    <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />

                                    <div class="form-group col-sm-4">
                                        <label for="heading"> Heading </label>
                                        <input type="text" required  name="heading" class="form-control"
                                            value="<?=$heading;?>" placeholder="Enter Heading">
                                    </div>

                                    <div class="form-group col-sm-4">
                                        <label for="image"> Image</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" accept="all" name="image" class="form-control"
                                                    id="image" <?php if(empty($image)){ echo "required"; }?>>
                                            </div>
                                            <?php if(!empty($image)) { ?>
                                            <img src="<?php echo base_url('uploads/').$image;?>" height="50px"
                                                width="50px" alt="">
                                            <?php  } ?>
                                        </div>
                                    </div>

                                    <div class="form-group col-sm-4">
                                        <label for="image_alt"> Image Alt </label>
                                        <input type="text" required  name="image_alt" class="form-control"
                                            value="<?=$image_alt;?>" placeholder="Enter Image Alt">
                                    </div>

                                   <div class="form-group col-sm-12">
                                        <label for="short_description"> Short Description </label>
                                        <textarea  required  name="short_description" class="form-control"
                                             placeholder="Enter Short Description"><?=$short_description;?></textarea>
                                    </div>
                                    
                                     <div class="form-group col-sm-4">
                                        <label for="priority">Priority</label>
                                        <input type="text" required  name="priority" class="form-control"
                                            value="<?=$priority;?>" placeholder="Enter Priority">
                                    </div>
                                    
                                    <div class="form-group col-sm-4">
                              <label for="image_alt"> Status </label>
                              <div class="form-check">
                                            <input class="form-check-input" name="status" type="checkbox" id="status"
                                                value="Active"
                                                <?php if(!empty($status && $status == "Active")){ echo"checked"; } ?>>
                                            <label class="form-check-label" for="status">Active</label>
                                        </div>
                           </div>
                                    

                         



                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<aside class="control-sidebar control-sidebar-dark"></aside>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script>
$('input[name="priority"]').keyup(function(e)
                                {
  if (/\D/g.test(this.value))
  {
    // Filter non-digits from input value.
    this.value = this.value.replace(/\D/g, '');
  }
});
</script>
