<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> <?=$settings['company_name'] ?? ''?> Login Panel</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="<?php echo base_url('assets/admin/'); ?>plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/admin/'); ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/admin/'); ?>dist/css/adminlte.min.css?v=3.2.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="card">
        <div class="login-logo pt-3">
            <a href="<?php echo base_url('admin/login');?>" class="">
                <img src="<?= !empty($settings['favicon']) ? base_url('uploads/'.$settings['favicon']) : ""; ?>" class="brand-image img-circle elevation-3" style="opacity: .8">
                <br>
                <b><?=$settings['company_name'] ?? 'Admin Login'?></b>
            </a>
        </div>
            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to start your session</p>
                <form action="<?php echo base_url('admin/check-login');?>" method="post">
                <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />
                    <div class="input-group mb-3">
                        <input type="email" name= "email" class="form-control" placeholder="Email">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" class="form-control" name="password" placeholder="Password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>

                    </div>
                   
                    <input type="submit" class="btn btn-outline-dark form-control" value="Login">
                </form>
            </div>
        </div>
    </div>
    <script src="<?php echo base_url('assets/admin/'); ?>plugins/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url('assets/admin/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url('assets/admin/'); ?>dist/js/adminlte.min.js?v=3.2.0"></script>
    <!-- toastr -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.12.1/sweetalert2.min.js"></script>
<script>
    	$(function() {
		    var Toast = Swal.mixin({
		      toast: true,
		      position: 'top-end',
		      showConfirmButton: false,
		      timer: 2000
		    });
			<?php if(session()->getFlashdata('success')){ ?>
				setTimeout(function() {
			    toastr.success('<?php echo session()->getFlashdata('success'); ?>')
			}, 1000);
			<?php } ?>
			<?php if(session()->getFlashdata('error')){ ?>
		    setTimeout(function() {
			    toastr.error('<?php echo session()->getFlashdata('error'); ?>.')
			}, 1000);
			<?php } ?>
		});
</script>
</body>
</html>