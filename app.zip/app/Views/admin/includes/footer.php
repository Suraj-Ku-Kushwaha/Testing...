<footer class="main-footer">
<!--     <strong>Copyright &copy; <?//=date('Y');?> <?=$settings['company_name'] ?? ''?> </strong>
    All rights reserved. -->
  </footer>
  <aside class="control-sidebar control-sidebar-dark">
  </aside>
</div>
          
<!-- jQuery -->
<script src="<?= base_url('assets/admin/plugins/');?>jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url('assets/admin/plugins/');?>bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?= base_url('assets/admin/plugins/');?>datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>jszip/jszip.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>pdfmake/pdfmake.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>pdfmake/vfs_fonts.js"></script>
<!-- <script src="<?= base_url('assets/admin/plugins/');?>datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?= base_url('assets/admin/plugins/');?>datatables-buttons/js/buttons.colVis.min.js"></script> -->
<!-- AdminLTE App -->
<script src="<?= base_url('assets/admin/');?>dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url('assets/admin/');?>dist/js/demo.js"></script>
<!-- Page specific script -->

<script>
  $(function () {
      $("#example1").DataTable({
        "responsive": true,"paging": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>

<!-- toastr -->
<!-- show form validation errors and success messages -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>

         <?php if(session()->getFlashdata('success')){ ?>
				setTimeout(function() {
			    toastr.success('<?php echo session()->getFlashdata('success'); ?>')
			}, 1000);
			<?php } ?>
			<?php if(session()->getFlashdata('failed')){ ?>
		    setTimeout(function() {
			    toastr.error('<?php echo session()->getFlashdata('failed'); ?>.')
			}, 1000);
			<?php } ?>


        <?php if (session()->has('errors')): ?>
            <?php foreach (session('errors') as $error): ?>
                toastr.error('<?= $error ?>');
            <?php endforeach; ?>
        <?php endif; ?>
    </script>

    
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function deleteData(href){
  Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.isConfirmed) {
      window.location = href;
      
  }
})
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.18.0/ckeditor.js"></script>
      <script>
        CKEDITOR.replace('description');
        CKEDITOR.replace('pricing');
    function getCount( type,table ){  
    $.ajax({
      url: '<?= base_url('admin/getCount') ?>',
      type: "POST",
      data: {'type': type,'table':table},
      cache: false,
        success:function(response) {   
            
         $('#'+ type ).html(response);
        }
      });
    }
    function loaddatavalue(){
  setTimeout( ()=>{ getCount( 'cms','dt_cms' ); },500 );
  setTimeout( ()=>{ getCount( 'blogs','dt_blogs' ); },600 );
  setTimeout( ()=>{ getCount( 'contact','dt_contactDetails' ); },800 );
  setTimeout( ()=>{ getCount( 'feedback','dt_feedback' ); },900 );

}
  window.load = loaddatavalue();   
</script>

<script>
function myFunction() {
  var x = document.getElementById("myInputPassword");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

</body>
</html>
