<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <!-- <h1 class="m-0">Dashboard </h1> -->
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('admin');?>">Home</a></li>
                        <li class="breadcrumb-item active">Testing List</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Testing list</h3>
                            <span><a href="<?php echo base_url('admin/add-process');?>" class="btn btn-primary float-right" >Add Testing</a></span>
                        </div>

                        <div class="card-body">
                            <table class="table table-bordered" id="example1">
                                <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Image</th>
                                        <th>Heading</th>
                                        <th>Priority</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                
                                </thead>
                                <tbody>

                                <?php
                                    if(!empty($processData)){
                                    $n=1;
                                    foreach ($processData as $key => $row) {?>


                                    <tr>
                                        <td><?php echo $n; ?></td>
                                        <td>
                                            <img src="<?php echo base_url('uploads/').$row['image'];?>" style="height: 50px; width: 50px;" alt="">
                                        </td>
                                        
                                        <td><?php echo $row['heading']; ?></td>

                                        <td><?php echo $row['priority']; ?></td>
                                        <td><?php echo $row['status']; ?></td>
                                        <td>
                                        <a href="<?php echo base_url('admin/add-process?id=').$row['id']; ?>" class="btn btn-primary"><i class="fas fa-pen"></i></a>
                                        <a onclick="deleteData('<?php echo base_url('admin/delete-process?id=') .$row['id'];?>')" class="btn btn-danger"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                        $n++; 
                                        }
                                        }
                                        ?>
                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<aside class="control-sidebar control-sidebar-dark">
</aside>


