<?php


if (!function_exists('db')) {
    function db() {
        $db = \Config\Database::connect();
        return $db;
    }
}




   function settings()
    {
        $db = db_connect();
        $builder = $db->table('dt_setting');
        return $builder->get()->getRowArray();
    }
    

    
    function headings()
    {
        $db = db_connect();
        $builder = $db->table('dt_headings');
        return $builder->get()->getRowArray();
    }




    function webView($page,$data){
        $data['settings'] = settings();
        $data['headings'] = headings();
        echo view('website/includes/header',$data);
        echo view('website/'.$page,$data);
        echo view('website/includes/footer',$data);
    }





function admin_view($page,$data){
     $data['settings'] = settings();
    $data['headings'] = headings();
    echo view('admin/includes/header',$data);
    echo view('admin/includes/navbar',$data);
    echo view('admin/includes/sidebar',$data);
    echo view('admin/'.$page,$data);
    echo view('admin/includes/footer',$data);
    
    }

// for webp jpg 
    if (!function_exists("getImage")) {
        function getImage($img = null, $imgWebp = null ){
            $path = base_url('uploads/');
            if(!empty($img) && !empty($img)){
                $imgUrl = $path.$img;
                $imgUrlWebp = $path.$imgWebp;
            }else{
                $imgUrl = '';
                $imgUrlWebp = ''; 
            }
            $agent = \Config\Services::request()->getUserAgent();
            if ($agent->isBrowser('Safari')) {
                return $imgUrl;
            }else{
                return $imgUrlWebp;
            }
        }
    }
    

    
    

    function login_view($page,$data){
        return view('admin/'.$page,$data);
        }


        if (!function_exists("convertImageInToWebp")) {
            function convertImageInToWebp($folderPath, $uploaded_file_name, $new_webp_file)
            {
                $source = $folderPath . '/' . $uploaded_file_name;
                $extension = pathinfo($source, PATHINFO_EXTENSION);
                $quality = 100;
                $image = '';
                if ($extension == 'jpeg' || $extension == 'jpg') {
                    $image = imagecreatefromjpeg($source);
                } elseif ($extension == 'gif') {
                    $image = imagecreatefromgif($source);
                } elseif ($extension == 'png') {
                    $image = imagecreatefrompng($source);
                    imagepalettetotruecolor($image); 
                }else{
                    return $uploaded_file_name;
                }
                $destination = $folderPath . '/' . $new_webp_file;
                $webp_upload_done = imagewebp($image, $destination, $quality);
                return $webp_upload_done ? $new_webp_file : '';
            }
        }

    
        // for webp jpg 
        if (!function_exists("getImgSrc")) {
          function getImgSrc($img = null, $imgWebp = null ){
              $path = base_url('uploads/');
              if(!empty($img) && !empty($img)){
                  $imgUrl = $path.$img;
                  $imgUrlWebp = $path.$imgWebp;
              }else{
                  $imgUrl = '';
                  $imgUrlWebp = ''; 
              }
              $agent = \Config\Services::request()->getUserAgent();
              if ($agent->isBrowser('Safari')) {
                  return $imgUrl;
              }else{
                  return $imgUrlWebp;
              }
          }
      }
      
        if (!function_exists('unlink_image')) {
            function unlink_image($path_to_image) {
                if (file_exists($path_to_image)) {
                    @unlink($path_to_image);
                }
                return true;
            }
        }
        
        
        if (!function_exists('count_data')) {
    function count_data($column, $table, $where = null) {
        $builder = db()->table($table);
        if (!empty($where)) {
            $builder->where($where);
        }
        $count = $builder->countAllResults($column);
        return $count;
    }
    

}

if (!function_exists("validate_slug")) {
    function validate_slug($text, string $divider = '-') {
        // Replace non-word characters (except the divider) with the divider
        $text = preg_replace('~[^\pL\d]+~u', $divider, $text);
        // Transliterate and remove diacritics
        $text = transliterator_transliterate('Any-Latin; Latin-ASCII', $text);
        // Remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);
        // Trim and remove duplicate dividers
        $text = trim($text, $divider);
        $text = preg_replace('~-+~', $divider, $text);
        // Convert to lowercase
        $text = strtolower($text);
        // If empty, return 'n-a'
        return empty($text) ? 'n-a' : $text;
    }
}
        

?>