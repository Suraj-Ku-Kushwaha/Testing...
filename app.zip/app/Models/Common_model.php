<?php
namespace App\Models;
use CodeIgniter\Model;

class Common_Model extends Model
{
    
    
 
    


    public function insertData($table,$data){
        $builder = $this->db->table($table);
         $result = $builder->insert($data);
         return $this->db->insertID();
    } 


    public function MultipleUpload($table, $data) {
        $builder = $this->db->table($table);
        $builder->insertBatch($data);
        return true;
    }

   



    public function updateData($table,$where=false,$data=null){
        $builder = $this->db->table($table);
        
        if(!empty($where)){
            $builder->where($where);
        }
        
        $result = $builder->update($data);
        return true;
    }


    public function setData($table, $where, $data)
    {
        $builder = $this->db->table($table);
        $builder->where($where);
        $result = $builder->update($data);
        return $result; // returns true on success, false on failure
    }



    public function deleteData($table,$where=false){
        $builder = $this->db->table($table);
        if(!empty($where)){
            $builder->where($where);
        }
        $result = $builder->delete();
        return $result;
    }

    
    public function getSingleData($table,$select=false,$where=false){
        $builder = $this->db->table($table);
        if(!empty($select)){
            $builder->select($select);
        }
        if(!empty($where)){
            $builder->where($where);
        }
        $result = $builder->get()->getRowArray();
        
        return $result;
    }
    public function getAllData($table,$select=false,$where=false , $orderBy = false, $limit = false){
        $builder = $this->db->table($table);
        if(!empty($select)){
            $builder->select($select);
        }
        if(!empty($where)){
            $builder->where($where);
        }

        if(!empty($orderBy)){
            $builder->orderBy($orderBy);
        }
        
          if (!empty($limit)) {
        $builder->limit($limit);
    }

        $result = $builder->get()->getResultArray();
        return $result;
    }

    public function checkLogin($table,$select=false,$where=false){
        $builder = $this->db->table($table);
        if(!empty($select)){
            $builder->select($select);
        }
        if(!empty($where)){
            $builder->where($where);
        }
        $result = $builder->get()->getRowArray();
       
        return $result;
        
        
    }

public function join(){
    $builder = $this->db->table('dt_courses');
    $builder->select('*');
    $builder->join('dt_course_duration', 'dt_course_duration.id = dt_courses.id');
    $query = $builder->get();

}


}